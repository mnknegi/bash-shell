#!/bin/bash

echo "This is my first bash script"

exit 0