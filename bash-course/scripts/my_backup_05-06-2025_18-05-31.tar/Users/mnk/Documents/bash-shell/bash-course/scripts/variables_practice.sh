#!/bin/bash

name="Mayank"
echo "Hello ${name}"

exit 0