#!/bin/bash

time=$(date +%H:%M:%S)
echo "Hello $USER, the time right now is $time"

exit 0